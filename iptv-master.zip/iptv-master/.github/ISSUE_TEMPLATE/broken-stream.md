---
name: Broken Stream
about: Any problems with the channel broadcasting
title: ''
labels: broken stream
assignees: ''

---

**What's wrong?**

**Country of the channel:**

**Channel Name:**

**Broken Link:**
<!-- Just copy the link to the broadcast from the playlist -->

**Additional Information (optional):**
