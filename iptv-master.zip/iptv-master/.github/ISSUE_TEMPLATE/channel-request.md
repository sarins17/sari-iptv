---
name: Channel Request
about: The playlists are missing your favorite channel
title: ''
labels: channel request
assignees: ''

---

**Country of the channel:**
<!-- If you are not sure what country the channel belongs to, use the search on https://www.lyngsat.com/search.html -->


**Channel Name:**
<!-- If you are looking for more than one channel from the same country, you can specify the list below -->


**Channel Language:**


**Additional Information (optional):**

